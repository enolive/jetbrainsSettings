class Something {
    fuckUp() {
        return false;
    }
}