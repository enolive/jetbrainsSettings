"use strict";

describe("Something", () => {
    beforeEach(() => {
        this.target = new Something();
    });

    it("should return true on fuck up", () => {
        expect(this.target.fuckUp()).toBeTruthy();
    });

    it("should do something else", () => {
       expect(this.target.fuckUp()).toBeFalsy();
    });
});